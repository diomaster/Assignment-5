class Quote < ApplicationRecord
end
